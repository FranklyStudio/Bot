// AutoPilot Bot - frame-accurate record & replay bot for Geometry Dash.
// Target: Geode 5.x, Geometry Dash 2.2081 (Android 64-bit build via GitHub Actions).
//
// How it works:
//   Record : every click/release is stored with the exact physics step it happened on.
//   Replay : the same clicks are injected on the same physics steps, and real taps are ignored.
//   Fixed Physics keeps the step timing identical on every run, which is what makes replays accurate.
//
// Runs are saved per level in this mod's save folder: macros/<level>.bot
//   online levels -> online_<id>.bot      local / editor levels -> local_<name>.bot

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace bot {

    enum class Mode { Off, Record, Replay };

    struct Input {
        uint32_t frame = 0;   // physics step (GJGameState::m_currentProgress)
        uint32_t call = 0;    // which processCommands() call inside that step
        int button = 1;       // 1 = jump, 2/3 = platformer left/right
        bool down = false;
        bool player1 = true;
    };

    struct HeldButton {
        int button;
        bool player1;
    };

    struct State {
        Mode mode = Mode::Off;
        std::vector<Input> macro;
        size_t replayIndex = 0;
        std::vector<HeldButton> pendingHeld;
        bool recordValid = false;        // true only if recording began at the start of an attempt
        bool injecting = false;          // true while the bot itself presses buttons
        bool inProcessCommands = false;
        uint32_t lastFrame = std::numeric_limits<uint32_t>::max();
        uint32_t callInFrame = 0;
        float accumulator = 0.f;
        float tickRate = 60.f;
        bool fixedPhysics = true;
        int64_t offset = 0;
        std::string levelKey = "unknown";
        PlayLayer* layer = nullptr;      // only compared, never dereferenced
    };

    inline State& state() {
        static State s;
        return s;
    }

    // ---------- small helpers ----------

    inline bool isPlayLayer(GJBaseGameLayer* gj) {
        auto pl = PlayLayer::get();
        return pl != nullptr && static_cast<GJBaseGameLayer*>(pl) == gj;
    }

    inline uint32_t currentFrame(GJBaseGameLayer* gj) {
        return static_cast<uint32_t>(gj->m_gameState.m_currentProgress);
    }

    // The (frame, call) slot that a button event belongs to right now.
    inline void currentKey(GJBaseGameLayer* gj, uint32_t& frame, uint32_t& call) {
        auto& s = state();
        uint32_t cur = currentFrame(gj);
        if (s.inProcessCommands) {
            frame = s.lastFrame;
            call = s.callInFrame;
        }
        else if (cur == s.lastFrame) {
            frame = cur;
            call = s.callInFrame + 1;
        }
        else {
            frame = cur;
            call = 0;
        }
    }

    inline char const* modeName(Mode m) {
        switch (m) {
            case Mode::Record: return "Record";
            case Mode::Replay: return "Replay";
            default: return "Off";
        }
    }

    inline Mode modeFromName(std::string const& n) {
        if (n == "Record") return Mode::Record;
        if (n == "Replay") return Mode::Replay;
        return Mode::Off;
    }

    inline std::string modeLabel() {
        return std::string("Bot: ") + modeName(state().mode);
    }

    inline void notify(std::string const& text, NotificationIcon icon = NotificationIcon::None) {
        Notification::create(text, icon, 2.5f)->show();
    }

    inline void readSettings() {
        auto& s = state();
        auto mod = Mod::get();
        s.offset = mod->getSettingValue<int64_t>("frame-offset");
        s.fixedPhysics = mod->getSettingValue<bool>("fixed-physics");
        auto tps = mod->getSettingValue<std::string>("physics-tps");
        s.tickRate = tps == "240" ? 240.f : (tps == "120" ? 120.f : 60.f);
    }

    // ---------- saving / loading ----------

    inline std::string sanitize(std::string const& in) {
        std::string out;
        for (unsigned char c : in) {
            out += std::isalnum(c) ? static_cast<char>(c) : '_';
        }
        if (out.empty()) out = "level";
        if (out.size() > 40) out.resize(40);
        return out;
    }

    inline std::string keyForLevel(GJGameLevel* level) {
        if (!level) return "unknown";
        int id = level->m_levelID.value();
        if (id > 0) return "online_" + std::to_string(id);
        return "local_" + sanitize(std::string(level->m_levelName));
    }

    inline auto macroPath(std::string const& key) {
        auto dir = Mod::get()->getSaveDir() / "macros";
        std::error_code ec;
        std::filesystem::create_directories(dir, ec);
        return dir / (key + ".bot");
    }

    inline bool saveMacro(std::string const& key, std::vector<Input> const& macro) {
        std::ofstream out(macroPath(key), std::ios::trunc);
        if (!out) return false;
        out << "GDBOT2\n";
        for (auto const& i : macro) {
            out << i.frame << ' ' << i.call << ' ' << i.button << ' '
                << (i.down ? 1 : 0) << ' ' << (i.player1 ? 1 : 0) << '\n';
        }
        return out.good();
    }

    inline bool loadMacro(std::string const& key, std::vector<Input>& macro) {
        std::ifstream in(macroPath(key));
        if (!in) return false;
        std::string header;
        std::getline(in, header);
        if (header.rfind("GDBOT2", 0) != 0) return false;
        macro.clear();
        Input i;
        int down = 0, p1 = 1;
        while (in >> i.frame >> i.call >> i.button >> down >> p1) {
            i.down = down != 0;
            i.player1 = p1 != 0;
            macro.push_back(i);
        }
        std::stable_sort(macro.begin(), macro.end(), [](Input const& a, Input const& b) {
            return a.frame != b.frame ? a.frame < b.frame : a.call < b.call;
        });
        return !macro.empty();
    }

    // ---------- mode control ----------

    inline void setMode(Mode m, bool announce) {
        auto& s = state();
        s.macro.clear();
        s.replayIndex = 0;
        s.pendingHeld.clear();
        s.recordValid = false;
        s.mode = m;
        if (m == Mode::Replay && !loadMacro(s.levelKey, s.macro)) {
            s.mode = Mode::Off;
            if (announce) {
                notify("No saved run for this level yet. Record one first.", NotificationIcon::Warning);
            }
        }
    }

    inline void cycleMode() {
        auto& s = state();
        Mode next = s.mode == Mode::Off ? Mode::Record
                  : (s.mode == Mode::Record ? Mode::Replay : Mode::Off);
        setMode(next, true);
        switch (s.mode) {
            case Mode::Record:
                notify("Record ON. Press Restart, then finish the level to save the run.", NotificationIcon::Success);
                break;
            case Mode::Replay:
                notify("Replay ON. Press Restart to start the bot.", NotificationIcon::Success);
                break;
            default:
                break;
        }
    }

    // ---------- replay ----------

    // Jump the replay pointer to `frame` (used after death / practice checkpoints).
    // Buttons that were held at that moment are re-pressed on the next step.
    inline void seekReplay(uint32_t frame) {
        auto& s = state();
        s.replayIndex = 0;
        s.pendingHeld.clear();
        std::vector<HeldButton> held;
        while (s.replayIndex < s.macro.size()) {
            auto const& e = s.macro[s.replayIndex];
            if (static_cast<int64_t>(e.frame) + s.offset >= static_cast<int64_t>(frame)) break;
            auto it = std::find_if(held.begin(), held.end(), [&](HeldButton const& h) {
                return h.button == e.button && h.player1 == e.player1;
            });
            if (e.down) {
                if (it == held.end()) held.push_back({e.button, e.player1});
            }
            else if (it != held.end()) {
                held.erase(it);
            }
            ++s.replayIndex;
        }
        s.pendingHeld = held;
    }

    inline void injectInputs(GJBaseGameLayer* gj) {
        auto& s = state();
        if (s.macro.empty() && s.pendingHeld.empty()) return;
        s.injecting = true;
        for (auto const& h : s.pendingHeld) {
            gj->handleButton(true, h.button, h.player1);
        }
        s.pendingHeld.clear();
        int64_t curFrame = static_cast<int64_t>(s.lastFrame);
        while (s.replayIndex < s.macro.size()) {
            auto const& e = s.macro[s.replayIndex];
            int64_t f = static_cast<int64_t>(e.frame) + s.offset;
            if (f > curFrame || (f == curFrame && e.call > s.callInFrame)) break;
            gj->handleButton(e.down, e.button, e.player1);
            ++s.replayIndex;
        }
        s.injecting = false;
    }

    // ---------- level events ----------

    inline void onNewSession(PlayLayer* pl) {
        auto& s = state();
        s.layer = pl;
        s.levelKey = keyForLevel(pl->m_level);
        auto start = Mod::get()->getSettingValue<std::string>("start-mode");
        setMode(modeFromName(start), false);
    }

    inline void onReset(PlayLayer* pl) {
        auto& s = state();
        readSettings();
        if (s.layer != pl) onNewSession(pl);

        uint32_t f = currentFrame(static_cast<GJBaseGameLayer*>(pl));
        s.lastFrame = std::numeric_limits<uint32_t>::max();
        s.callInFrame = 0;
        s.accumulator = 0.f;
        s.inProcessCommands = false;

        if (s.mode == Mode::Record) {
            if (f == 0) {
                s.macro.clear();
                s.recordValid = true;
            }
            else if (s.recordValid) {
                // practice-mode respawn: drop everything recorded after the checkpoint
                while (!s.macro.empty() && s.macro.back().frame >= f) s.macro.pop_back();
            }
        }
        else if (s.mode == Mode::Replay) {
            seekReplay(f);
        }
    }

    inline void onComplete() {
        auto& s = state();
        if (s.mode != Mode::Record || !s.recordValid || s.macro.empty()) return;
        if (saveMacro(s.levelKey, s.macro)) {
            notify("Run saved (" + std::to_string(s.macro.size()) + " inputs)", NotificationIcon::Success);
        }
        else {
            notify("Could not save the run", NotificationIcon::Error);
        }
    }

}

// ---------- hooks ----------

class $modify(BotBaseLayer, GJBaseGameLayer) {
    // Fixed-rate physics: identical step timing on every run = accurate replays.
    void update(float dt) {
        auto& s = bot::state();
        if (s.mode == bot::Mode::Off || !s.fixedPhysics || !bot::isPlayLayer(this)) {
            GJBaseGameLayer::update(dt);
            return;
        }
        float step = 1.f / s.tickRate;
        s.accumulator += dt;
        int runs = 0;
        while (s.accumulator >= step * 0.95f && runs < 8) {
            GJBaseGameLayer::update(step);
            s.accumulator -= step;
            ++runs;
        }
        if (runs == 8) s.accumulator = 0.f;
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto& s = bot::state();
        if (!bot::isPlayLayer(this)) {
            GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
            return;
        }

        uint32_t frame = bot::currentFrame(this);
        if (frame != s.lastFrame) {
            s.lastFrame = frame;
            s.callInFrame = 0;
        }
        else {
            ++s.callInFrame;
        }

        if (s.mode == bot::Mode::Replay) bot::injectInputs(this);

        s.inProcessCommands = true;
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        s.inProcessCommands = false;
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        auto& s = bot::state();
        if (!s.injecting && bot::isPlayLayer(this)) {
            // bot is driving: ignore real taps
            if (s.mode == bot::Mode::Replay && !s.macro.empty()) return;

            if (s.mode == bot::Mode::Record && s.recordValid) {
                bot::Input in;
                bot::currentKey(this, in.frame, in.call);
                in.button = button;
                in.down = down;
                in.player1 = isPlayer1;
                s.macro.push_back(in);
            }
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
};

class $modify(BotPlayLayer, PlayLayer) {
    void resetLevel() {
        PlayLayer::resetLevel();
        bot::onReset(this);
    }

    void levelComplete() {
        bot::onComplete();
        PlayLayer::levelComplete();
    }
};

class $modify(BotPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto win = CCDirector::get()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});

        auto sprite = ButtonSprite::create("Bot", "goldFont.fnt", "GJ_button_01.png", 0.8f);
        auto button = CCMenuItemSpriteExtra::create(
            sprite, this, menu_selector(BotPauseLayer::onBotToggle)
        );
        button->setPosition({win.width - 80.f, 36.f});
        menu->addChild(button);

        auto label = CCLabelBMFont::create(bot::modeLabel().c_str(), "bigFont.fnt");
        label->setScale(0.45f);
        label->setPosition({win.width - 80.f, 62.f});
        label->setTag(7771);
        menu->addChild(label);

        this->addChild(menu, 100);
    }

    void onBotToggle(CCObject* sender) {
        bot::cycleMode();
        if (auto node = typeinfo_cast<CCNode*>(sender)) {
            if (auto parent = node->getParent()) {
                if (auto label = typeinfo_cast<CCLabelBMFont*>(parent->getChildByTag(7771))) {
                    label->setString(bot::modeLabel().c_str());
                }
            }
        }
    }
};

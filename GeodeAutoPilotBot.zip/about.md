# AutoPilot Bot

A frame-accurate **record and replay bot**. Record a run once, then let the bot replay it perfectly. Works on any level: official, online user-made, and local/editor levels.

## How to use
1. Open the pause menu and tap the **Bot** button (bottom right) until it says **Record**.
2. Tap **Restart**, then play the level to the end. The run saves automatically when you finish.
3. Tap **Bot** until it says **Replay**, tap **Restart**, and watch the bot play. Real taps are ignored while it replays.

Tip: record in Practice Mode with checkpoints. After a death the run rewinds to the checkpoint, so you only keep the good part.

## Settings
- **Start Mode**: what the bot does when a level opens (set to Replay to have saved levels play themselves).
- **Fixed Physics**: keeps physics timing identical every run so replays do not drift when FPS changes.
- **Physics Rate**: 60 is safest on phones.
- **Frame Offset**: leave at 0; try -1 or 1 only if replays are always slightly early or late.

## Good to know
- It replays runs you recorded. It does not figure out levels by itself.
- Levels with random triggers can behave differently each attempt, so they may desync.
- Use it for practice and showcases. Do not submit botted runs to leaderboards or lists.

# AutoPilot Bot

A bot that **plays Geometry Dash by itself**. Open a level, turn the bot on, and watch it learn the level and beat it. A name tag shows on screen while it plays.

## How to use
1. Open any level and pause. Tap the **Bot** button (bottom right) until it says **Auto**.
2. Tap **Restart**. The bot starts playing. It dies, fixes its clicks near where it died, and tries again, getting further each time.
3. When it beats the level, it saves the run. Tap **Bot** until it says **Replay** and tap **Restart** to watch it play the whole level instantly.

Other modes: **Record** (you play, the bot saves your run) and **Replay** (plays a saved run).

## Settings
- **Bot Name**: the name shown on screen.
- **Record Speed**: slow motion while you record (try 0.25). Replays still run at full speed.
- **Fast Learning**: runs attempts as fast as your phone can. Turn off if it gets hot or laggy.
- **Start Mode**: set to Auto to make the bot start by itself whenever you open a level.
- **Fixed Physics / Physics Rate / Frame Offset**: accuracy settings. Leave them as they are.

## Hard levels (extreme demons)
Auto cannot beat these by itself. The way bots beat them is a human run recorded in slow motion:
1. Set **Record Speed** to 0.25 and Start Mode to Record (or use the Bot button).
2. Play in **Practice Mode** with lots of checkpoints. When you die, it rewinds to the checkpoint and keeps only the good part.
3. Finish the level. The run saves. Switch to Replay and the bot plays it at full speed.

## Good to know
- The bot learns by trial and error, so easy and medium cube levels work best. Hard levels, wave sections and fast ship sections can leave it stuck. It tells you where it got stuck.
- Use it in normal mode, not Practice Mode.
- Levels with random triggers can behave differently each attempt.
- Use it for practice and showcases. Do not submit botted runs to leaderboards or lists.

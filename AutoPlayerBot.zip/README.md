# AutoPilot Bot - build and install (phone only)

You need a free GitHub account. GitHub builds the Android file for you. Nothing to install.

## 1. Build it
1. On github.com create a new repository (name it anything, set it Public).
2. Open the repo, tap **Add file > Upload files**, upload **GeodeAutoPilotBot.zip** (the zip you downloaded; do NOT unzip it), then **Commit**.
   - Can't see "Add file"? Switch your browser to **Desktop site**.
3. Tap **Add file > Create new file**. In the name box type exactly `.github/workflows/build.yml`
   and paste in the contents of `build.yml` (it's inside the zip, and I also put it in the chat message), then **Commit**.
4. Tap the **Actions** tab. The build starts by itself (about 5 to 10 minutes). If it doesn't, open the workflow and tap **Run workflow**.
5. When the run has a green check, open it, scroll to **Artifacts**, tap **AutoPilotBot-android** to download.
6. Unzip the download with your Files app. You get `autopilot.replaybot.geode`.

## 2. Install it
- In Geometry Dash: Geode menu > Mods > **Install from file** > pick the .geode file, then restart the game.
- Or copy the .geode into: `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`

Needs Geometry Dash 2.2081 with Geode 5 on Android.

## 3. Test checklist
1. Open an EASY level, pause. A **Bot** button and "Bot: Off" label appear at the bottom right.
2. Tap Bot once ("Bot: Auto"), tap Restart. A name tag shows top left with the attempt number and best time. The bot should get further over time.
3. When it wins you get a "Bot beat the level" notice. Tap Bot until "Bot: Replay", tap Restart, and it plays the level start to finish.
4. If a replay dies slightly early or late every time, set **Frame Offset** to -1 or 1 in the mod's settings.
5. If the game runs at the wrong speed, turn **Fixed Physics** off. If the phone gets hot, turn **Fast Learning** off.

Auto is a learning bot: it works on easy and medium cube levels, and can get stuck on hard parts (wave, fast ship). Start with an easy level first.

## Extreme demons
Auto cannot beat them alone. Use slow-motion recording instead: set **Record Speed** to 0.25 in the mod settings, set the Bot button to Record, play the level in Practice Mode with many checkpoints, and finish it. Then switch to Replay.

## If the build fails
Open the failed run in the Actions tab, copy the red error lines, and send them to me. The hooks were checked against the Geode docs but never compiled against the real SDK.

Saved runs live in the mod's save folder under `macros/` (one file per level).

// AutoPilot Bot - auto player + frame-accurate record & replay bot for Geometry Dash.
// Target: Geode 5.x, Geometry Dash 2.2081 (Android 64-bit build via GitHub Actions).
//
// How it works:
//   Auto   : the bot plays by itself. It tries, dies, changes a click near where it died, and tries again
//            until it beats the level (a "learning" bot). When it wins, the run is saved.
//   Record : every click/release is stored with the exact physics step it happened on.
//   Replay : the same clicks are injected on the same physics steps, and real taps are ignored.
//   Fixed Physics keeps the step timing identical on every run, which is what makes replays accurate.
//
// Runs are saved per level in this mod's save folder: macros/<level>.bot
//   online levels -> online_<id>.bot      local / editor levels -> local_<name>.bot

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace bot {

    enum class Mode { Off, Auto, Replay, Record };

    struct Input {
        uint32_t frame = 0;   // physics step (GJGameState::m_currentProgress)
        uint32_t call = 0;    // which processCommands() call inside that step
        int button = 1;       // 1 = jump, 2/3 = platformer left/right
        bool down = false;
        bool player1 = true;
    };

    struct HeldButton {
        int button;
        bool player1;
    };

    // one click = press at step t, release at step t + dur (button 1, player 1)
    struct Click {
        uint32_t t = 0;
        uint32_t dur = 1;
    };

    struct Cand {
        enum Kind { Add, Remove, Shift } kind = Add;
        uint32_t t = 0;
        uint32_t dur = 1;
        int idx = 0;
        int delta = 0;
    };

    struct AutoState {
        std::vector<Click> base;     // clicks we trust so far
        std::vector<Click> trial;    // base + the candidate being tested this attempt
        std::vector<Cand> cands;
        size_t candIdx = 0;
        uint32_t bestD = 0;          // step where the base run died
        uint32_t lookback = 120;     // how far back from the death we are allowed to change things
        uint32_t winLow = 0;         // candidate window already searched: [winLow, winHigh]
        bool baseRun = true;         // first attempt just runs the base as-is
        bool pendingTrial = false;
        bool deathSeen = false;
        uint32_t deathFrame = 0;
        int attempts = 0;
    };

    struct State {
        Mode mode = Mode::Off;
        AutoState autoS;
        bool turbo = true;
        float recordSpeed = 1.f;   // slow motion while recording (1 = normal)
        std::string botName = "Alex";
        std::vector<Input> macro;
        size_t replayIndex = 0;
        std::vector<HeldButton> pendingHeld;
        bool recordValid = false;        // true only if recording began at the start of an attempt
        bool injecting = false;          // true while the bot itself presses buttons
        bool inProcessCommands = false;
        uint32_t lastFrame = std::numeric_limits<uint32_t>::max();
        uint32_t callInFrame = 0;
        float accumulator = 0.f;
        float tickRate = 60.f;
        bool fixedPhysics = true;
        int64_t offset = 0;
        std::string levelKey = "unknown";
        PlayLayer* layer = nullptr;      // only compared, never dereferenced
    };

    inline State& state() {
        static State s;
        return s;
    }

    // ---------- small helpers ----------

    inline bool isPlayLayer(GJBaseGameLayer* gj) {
        auto pl = PlayLayer::get();
        return pl != nullptr && static_cast<GJBaseGameLayer*>(pl) == gj;
    }

    inline uint32_t currentFrame(GJBaseGameLayer* gj) {
        return static_cast<uint32_t>(gj->m_gameState.m_currentProgress);
    }

    // The (frame, call) slot that a button event belongs to right now.
    inline void currentKey(GJBaseGameLayer* gj, uint32_t& frame, uint32_t& call) {
        auto& s = state();
        uint32_t cur = currentFrame(gj);
        if (s.inProcessCommands) {
            frame = s.lastFrame;
            call = s.callInFrame;
        }
        else if (cur == s.lastFrame) {
            frame = cur;
            call = s.callInFrame + 1;
        }
        else {
            frame = cur;
            call = 0;
        }
    }

    inline char const* modeName(Mode m) {
        switch (m) {
            case Mode::Auto: return "Auto";
            case Mode::Record: return "Record";
            case Mode::Replay: return "Replay";
            default: return "Off";
        }
    }

    inline Mode modeFromName(std::string const& n) {
        if (n == "Auto") return Mode::Auto;
        if (n == "Record") return Mode::Record;
        if (n == "Replay") return Mode::Replay;
        return Mode::Off;
    }

    inline std::string modeLabel() {
        return std::string("Bot: ") + modeName(state().mode);
    }

    inline void notify(std::string const& text, NotificationIcon icon = NotificationIcon::None) {
        Notification::create(text, icon, 2.5f)->show();
    }

    inline void readSettings() {
        auto& s = state();
        auto mod = Mod::get();
        s.offset = mod->getSettingValue<int64_t>("frame-offset");
        s.fixedPhysics = mod->getSettingValue<bool>("fixed-physics");
        auto tps = mod->getSettingValue<std::string>("physics-tps");
        s.tickRate = tps == "240" ? 240.f : (tps == "120" ? 120.f : 60.f);
        s.turbo = mod->getSettingValue<bool>("fast-learning");
        s.recordSpeed = std::clamp(static_cast<float>(mod->getSettingValue<double>("record-speed")), 0.05f, 1.f);
        s.botName = mod->getSettingValue<std::string>("bot-name");
        if (s.botName.empty()) s.botName = "Alex";
    }

    // ---------- saving / loading ----------

    inline std::string sanitize(std::string const& in) {
        std::string out;
        for (unsigned char c : in) {
            out += std::isalnum(c) ? static_cast<char>(c) : '_';
        }
        if (out.empty()) out = "level";
        if (out.size() > 40) out.resize(40);
        return out;
    }

    inline std::string keyForLevel(GJGameLevel* level) {
        if (!level) return "unknown";
        int id = level->m_levelID;
        if (id > 0) return "online_" + std::to_string(id);
        return "local_" + sanitize(std::string(level->m_levelName));
    }

    inline auto macroPath(std::string const& key) {
        auto dir = Mod::get()->getSaveDir() / "macros";
        std::error_code ec;
        std::filesystem::create_directories(std::filesystem::path(dir.string()), ec);
        return dir / (key + ".bot");
    }

    inline bool saveMacro(std::string const& key, std::vector<Input> const& macro) {
        std::ofstream out(macroPath(key).string(), std::ios::trunc);
        if (!out) return false;
        out << "GDBOT2\n";
        for (auto const& i : macro) {
            out << i.frame << ' ' << i.call << ' ' << i.button << ' '
                << (i.down ? 1 : 0) << ' ' << (i.player1 ? 1 : 0) << '\n';
        }
        return out.good();
    }

    inline bool loadMacro(std::string const& key, std::vector<Input>& macro) {
        std::ifstream in(macroPath(key).string());
        if (!in) return false;
        std::string header;
        std::getline(in, header);
        if (header.rfind("GDBOT2", 0) != 0) return false;
        macro.clear();
        Input i;
        int down = 0, p1 = 1;
        while (in >> i.frame >> i.call >> i.button >> down >> p1) {
            i.down = down != 0;
            i.player1 = p1 != 0;
            macro.push_back(i);
        }
        std::stable_sort(macro.begin(), macro.end(), [](Input const& a, Input const& b) {
            return a.frame != b.frame ? a.frame < b.frame : a.call < b.call;
        });
        return !macro.empty();
    }

    // ---------- mode control ----------

    inline void setTimeScale(float scale) {
        if (auto d = CCDirector::get()) {
            if (auto sch = d->getScheduler()) sch->setTimeScale(scale);
        }
    }

    inline void setMode(Mode m, bool announce) {
        auto& s = state();
        s.macro.clear();
        s.replayIndex = 0;
        s.pendingHeld.clear();
        s.recordValid = false;
        s.autoS = AutoState{};
        s.mode = m;
        // Auto speeds up the dead-time between attempts; everything else runs at normal speed.
        setTimeScale(m == Mode::Auto ? 4.f : 1.f);
        if (m == Mode::Replay && !loadMacro(s.levelKey, s.macro)) {
            s.mode = Mode::Off;
            if (announce) {
                notify("No saved run for this level yet. Let the bot learn it (Auto) or Record one.", NotificationIcon::Warning);
            }
        }
    }

    inline void cycleMode() {
        auto& s = state();
        Mode next = Mode::Off;
        switch (s.mode) {
            case Mode::Off:    next = Mode::Auto; break;
            case Mode::Auto:   next = Mode::Replay; break;
            case Mode::Replay: next = Mode::Record; break;
            default:           next = Mode::Off; break;
        }
        setMode(next, true);
        switch (s.mode) {
            case Mode::Auto:
                notify("Auto ON. Press Restart and the bot starts learning the level.", NotificationIcon::Success);
                break;
            case Mode::Record:
                notify("Record ON. Press Restart, then finish the level to save the run.", NotificationIcon::Success);
                break;
            case Mode::Replay:
                notify("Replay ON. Press Restart to start the bot.", NotificationIcon::Success);
                break;
            default:
                break;
        }
    }

    // ---------- replay ----------

    // Jump the replay pointer to `frame` (used after death / practice checkpoints).
    // Buttons that were held at that moment are re-pressed on the next step.
    inline void seekReplay(uint32_t frame) {
        auto& s = state();
        s.replayIndex = 0;
        s.pendingHeld.clear();
        std::vector<HeldButton> held;
        while (s.replayIndex < s.macro.size()) {
            auto const& e = s.macro[s.replayIndex];
            if (static_cast<int64_t>(e.frame) + s.offset >= static_cast<int64_t>(frame)) break;
            auto it = std::find_if(held.begin(), held.end(), [&](HeldButton const& h) {
                return h.button == e.button && h.player1 == e.player1;
            });
            if (e.down) {
                if (it == held.end()) held.push_back({e.button, e.player1});
            }
            else if (it != held.end()) {
                held.erase(it);
            }
            ++s.replayIndex;
        }
        s.pendingHeld = held;
    }

    inline void injectInputs(GJBaseGameLayer* gj) {
        auto& s = state();
        if (s.macro.empty() && s.pendingHeld.empty()) return;
        s.injecting = true;
        for (auto const& h : s.pendingHeld) {
            gj->handleButton(true, h.button, h.player1);
        }
        s.pendingHeld.clear();
        int64_t curFrame = static_cast<int64_t>(s.lastFrame);
        while (s.replayIndex < s.macro.size()) {
            auto const& e = s.macro[s.replayIndex];
            int64_t f = static_cast<int64_t>(e.frame) + s.offset;
            if (f > curFrame || (f == curFrame && e.call > s.callInFrame)) break;
            gj->handleButton(e.down, e.button, e.player1);
            ++s.replayIndex;
        }
        s.injecting = false;
    }

    // ---------- the learning bot (Auto) ----------
    //
    // Idea: play the level, and every time we die, change a click shortly before the death spot
    // (add a tap, remove a click, or nudge a click earlier/later). If the new version survives longer,
    // keep it. If not, throw it away and try the next idea. Repeat until the level is beaten.
    // Because physics is fixed-rate, replaying the kept clicks reaches the same spot every time.

    constexpr uint32_t kMinGain = 6;         // must survive at least this many steps longer to keep a change
    constexpr uint32_t kStartLookback = 120; // steps before the death spot we are allowed to change
    constexpr uint32_t kMaxLookback = 960;   // give up beyond this
    constexpr size_t kMaxCands = 2500;

    inline bool clicksValid(std::vector<Click> const& c) {
        for (size_t i = 0; i < c.size(); ++i) {
            if (c[i].dur < 1) return false;
            if (i > 0 && c[i].t <= c[i - 1].t + c[i - 1].dur) return false;   // overlap / touching
        }
        return true;
    }

    inline void sortClicks(std::vector<Click>& c) {
        std::sort(c.begin(), c.end(), [](Click const& a, Click const& b) { return a.t < b.t; });
    }

    inline bool applyCand(std::vector<Click> const& base, Cand const& cd, std::vector<Click>& out) {
        out = base;
        switch (cd.kind) {
            case Cand::Add:
                out.push_back({cd.t, cd.dur});
                break;
            case Cand::Remove:
                if (cd.idx < 0 || static_cast<size_t>(cd.idx) >= out.size()) return false;
                out.erase(out.begin() + cd.idx);
                break;
            case Cand::Shift: {
                if (cd.idx < 0 || static_cast<size_t>(cd.idx) >= out.size()) return false;
                int64_t nt = static_cast<int64_t>(out[cd.idx].t) + cd.delta;
                if (nt < 0) return false;
                out[cd.idx].t = static_cast<uint32_t>(nt);
                break;
            }
        }
        sortClicks(out);
        return clicksValid(out);
    }

    // Candidate changes whose position lies in [low, high] (steps).
    inline void buildCands(uint32_t low, uint32_t high) {
        auto& a = state().autoS;
        a.cands.clear();
        a.candIdx = 0;
        a.winLow = low;
        static const uint32_t durs[] = {4, 10, 24, 60};
        for (uint32_t d : durs) {
            for (int64_t t = high; t >= static_cast<int64_t>(low); t -= 2) {
                Cand c; c.kind = Cand::Add; c.t = static_cast<uint32_t>(t); c.dur = d;
                a.cands.push_back(c);
            }
        }
        for (size_t i = 0; i < a.base.size(); ++i) {
            if (a.base[i].t < low || a.base[i].t > high + 30) continue;
            Cand r; r.kind = Cand::Remove; r.idx = static_cast<int>(i);
            a.cands.push_back(r);
        }
        static const int deltas[] = {-1, 1, -2, 2, -3, 3, -5, 5, -8, 8, -12, 12, -20, 20, -30, 30};
        for (size_t i = 0; i < a.base.size(); ++i) {
            if (a.base[i].t < low || a.base[i].t > high + 30) continue;
            for (int dl : deltas) {
                Cand c; c.kind = Cand::Shift; c.idx = static_cast<int>(i); c.delta = dl;
                a.cands.push_back(c);
            }
        }
        if (a.cands.size() > kMaxCands) a.cands.resize(kMaxCands);
    }

    inline void compileClicks(std::vector<Click> const& clicks, std::vector<Input>& out) {
        out.clear();
        for (auto const& c : clicks) {
            Input down; down.frame = c.t; down.call = 0; down.button = 1; down.down = true; down.player1 = true;
            Input up = down; up.frame = c.t + c.dur; up.down = false;
            out.push_back(down);
            out.push_back(up);
        }
        std::stable_sort(out.begin(), out.end(), [](Input const& a, Input const& b) {
            if (a.frame != b.frame) return a.frame < b.frame;
            if (a.call != b.call) return a.call < b.call;
            return a.down < b.down;   // release before press on the same step
        });
    }

    inline void autoGiveUp() {
        auto& s = state();
        float secs = static_cast<float>(s.autoS.bestD) / 240.f;
        char buf[96];
        std::snprintf(buf, sizeof buf, "Bot is stuck at %.1fs. This part is too hard for it.", secs);
        setMode(Mode::Off, false);
        notify(buf, NotificationIcon::Warning);
    }

    // Called at the start of every attempt while Auto is on.
    inline void autoPrepareAttempt() {
        auto& s = state();
        auto& a = s.autoS;
        ++a.attempts;

        if (a.deathSeen) {
            uint32_t D = a.deathFrame;
            a.deathSeen = false;
            if (a.baseRun) {
                a.baseRun = false;
                a.bestD = D;
                a.lookback = kStartLookback;
                uint32_t low = D > a.lookback ? D - a.lookback : 0;
                buildCands(low, D > 4 ? D - 4 : 0);
            }
            else if (a.pendingTrial && D >= a.bestD + kMinGain) {
                a.base = a.trial;            // the change worked: keep it
                a.bestD = D;
                a.lookback = kStartLookback;
                uint32_t low = D > a.lookback ? D - a.lookback : 0;
                buildCands(low, D > 4 ? D - 4 : 0);
            }
            a.pendingTrial = false;
        }

        if (a.baseRun) {
            a.trial = a.base;
        }
        else {
            for (;;) {
                if (a.candIdx >= a.cands.size()) {
                    // nothing left to try here: look further back
                    if (a.lookback >= kMaxLookback || a.winLow == 0) { autoGiveUp(); return; }
                    uint32_t oldLow = a.winLow;
                    a.lookback = std::min(a.lookback * 2, kMaxLookback);
                    uint32_t low = a.bestD > a.lookback ? a.bestD - a.lookback : 0;
                    buildCands(low, oldLow > 0 ? oldLow - 1 : 0);
                    continue;
                }
                Cand c = a.cands[a.candIdx++];
                if (applyCand(a.base, c, a.trial)) {
                    a.pendingTrial = true;
                    break;
                }
            }
        }
        compileClicks(a.trial, s.macro);
    }

    inline void onDeath(PlayLayer* pl) {
        auto& s = state();
        if (s.mode != Mode::Auto || s.autoS.deathSeen) return;
        s.autoS.deathSeen = true;
        s.autoS.deathFrame = currentFrame(static_cast<GJBaseGameLayer*>(pl));
    }

    // ---------- on-screen name tag ----------

    inline void updateNameTag(PlayLayer* pl) {
        auto& s = state();
        auto label = typeinfo_cast<CCLabelBMFont*>(pl->getChildByTag(7772));
        if (!label) {
            label = CCLabelBMFont::create("", "bigFont.fnt");
            label->setTag(7772);
            label->setAnchorPoint({0.f, 1.f});
            label->setScale(0.4f);
            auto win = CCDirector::get()->getWinSize();
            label->setPosition({8.f, win.height - 8.f});
            pl->addChild(label, 1000);
        }
        bool show = s.mode == Mode::Auto || s.mode == Mode::Replay;
        label->setVisible(show);
        if (!show) return;
        std::string text = "Bot " + s.botName;
        if (s.mode == Mode::Auto) {
            char buf[64];
            std::snprintf(buf, sizeof buf, "   attempt %d   best %.1fs",
                s.autoS.attempts, static_cast<double>(s.autoS.bestD) / 240.0);
            text += buf;
        }
        label->setString(text.c_str());
    }

    // ---------- level events ----------

    inline void onNewSession(PlayLayer* pl) {
        auto& s = state();
        s.layer = pl;
        s.levelKey = keyForLevel(pl->m_level);
        auto start = Mod::get()->getSettingValue<std::string>("start-mode");
        setMode(modeFromName(start), false);
    }

    inline void leaveSession() {
        auto& s = state();
        s.mode = Mode::Off;
        s.layer = nullptr;
        setTimeScale(1.f);
    }

    inline void onReset(PlayLayer* pl) {
        auto& s = state();
        readSettings();
        if (s.layer != pl) onNewSession(pl);

        uint32_t f = currentFrame(static_cast<GJBaseGameLayer*>(pl));
        s.lastFrame = std::numeric_limits<uint32_t>::max();
        s.callInFrame = 0;
        s.accumulator = 0.f;
        s.inProcessCommands = false;

        if (s.mode == Mode::Record) {
            if (f == 0) {
                s.macro.clear();
                s.recordValid = true;
            }
            else if (s.recordValid) {
                // practice-mode respawn: drop everything recorded after the checkpoint
                while (!s.macro.empty() && s.macro.back().frame >= f) s.macro.pop_back();
            }
        }
        else if (s.mode == Mode::Auto) {
            if (f == 0) autoPrepareAttempt();   // may switch the mode off if the bot gives up
            if (s.mode == Mode::Auto) seekReplay(f);
        }
        else if (s.mode == Mode::Replay) {
            seekReplay(f);
        }
        updateNameTag(pl);
    }

    inline void onComplete() {
        auto& s = state();
        if (s.mode == Mode::Auto) {
            int attempts = s.autoS.attempts;
            bool saved = !s.macro.empty() && saveMacro(s.levelKey, s.macro);
            setMode(Mode::Off, false);
            notify(std::string("Bot beat the level on attempt ") + std::to_string(attempts)
                   + (saved ? ". Saved! Use Replay to watch it again." : "."),
                   NotificationIcon::Success);
            return;
        }
        if (s.mode != Mode::Record || !s.recordValid || s.macro.empty()) return;
        if (saveMacro(s.levelKey, s.macro)) {
            notify("Run saved (" + std::to_string(s.macro.size()) + " inputs)", NotificationIcon::Success);
        }
        else {
            notify("Could not save the run", NotificationIcon::Error);
        }
    }

}

// ---------- hooks ----------

class $modify(BotBaseLayer, GJBaseGameLayer) {
    // Fixed-rate physics: identical step timing on every run = accurate replays and a reliable learner.
    void update(float dt) {
        auto& s = bot::state();
        bool active = s.mode != bot::Mode::Off && bot::isPlayLayer(this);
        bool slowRecord = s.mode == bot::Mode::Record && s.recordSpeed < 0.999f;
        bool wantFixed = s.fixedPhysics || s.mode == bot::Mode::Auto || slowRecord;
        if (!active || !wantFixed) {
            GJBaseGameLayer::update(dt);
            return;
        }
        float step = 1.f / s.tickRate;

        if (s.mode == bot::Mode::Auto && s.turbo) {
            // Fast learning: run as many fixed steps as fit in a few milliseconds each frame.
            auto t0 = std::chrono::steady_clock::now();
            int runs = 0;
            do {
                GJBaseGameLayer::update(step);
                ++runs;
            } while (runs < 64 &&
                     std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() < 8.0);
            return;
        }

        // Slow motion only changes how fast steps happen, never what a step is,
        // so a run recorded in slow motion replays correctly at full speed.
        s.accumulator += slowRecord ? dt * s.recordSpeed : dt;
        int runs = 0;
        while (s.accumulator >= step * 0.95f && runs < 8) {
            GJBaseGameLayer::update(step);
            s.accumulator -= step;
            ++runs;
        }
        if (runs == 8) s.accumulator = 0.f;
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto& s = bot::state();
        if (!bot::isPlayLayer(this)) {
            GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
            return;
        }

        uint32_t frame = bot::currentFrame(this);
        if (frame != s.lastFrame) {
            s.lastFrame = frame;
            s.callInFrame = 0;
        }
        else {
            ++s.callInFrame;
        }

        if (s.mode == bot::Mode::Replay || s.mode == bot::Mode::Auto) bot::injectInputs(this);

        s.inProcessCommands = true;
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        s.inProcessCommands = false;
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        auto& s = bot::state();
        if (!s.injecting && bot::isPlayLayer(this)) {
            // the bot is driving: ignore real taps
            if (s.mode == bot::Mode::Auto) return;
            if (s.mode == bot::Mode::Replay && !s.macro.empty()) return;

            if (s.mode == bot::Mode::Record && s.recordValid) {
                bot::Input in;
                bot::currentKey(this, in.frame, in.call);
                in.button = button;
                in.down = down;
                in.player1 = isPlayer1;
                s.macro.push_back(in);
            }
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
};

class $modify(BotPlayLayer, PlayLayer) {
    void resetLevel() {
        PlayLayer::resetLevel();
        bot::onReset(this);
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bot::onDeath(this);
        PlayLayer::destroyPlayer(player, object);
    }

    void levelComplete() {
        bot::onComplete();
        PlayLayer::levelComplete();
    }

    void onExit() {
        bot::leaveSession();
        PlayLayer::onExit();
    }
};

class $modify(BotPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto win = CCDirector::get()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});

        auto sprite = ButtonSprite::create("Bot", "goldFont.fnt", "GJ_button_01.png", 0.8f);
        auto button = CCMenuItemSpriteExtra::create(
            sprite, this, menu_selector(BotPauseLayer::onBotToggle)
        );
        button->setPosition({win.width - 80.f, 36.f});
        menu->addChild(button);

        auto label = CCLabelBMFont::create(bot::modeLabel().c_str(), "bigFont.fnt");
        label->setScale(0.45f);
        label->setPosition({win.width - 80.f, 62.f});
        label->setTag(7771);
        menu->addChild(label);

        this->addChild(menu, 100);
    }

    void onBotToggle(CCObject* sender) {
        bot::cycleMode();
        if (auto node = typeinfo_cast<CCNode*>(sender)) {
            if (auto parent = node->getParent()) {
                if (auto label = typeinfo_cast<CCLabelBMFont*>(parent->getChildByTag(7771))) {
                    label->setString(bot::modeLabel().c_str());
                }
            }
        }
    }
};
